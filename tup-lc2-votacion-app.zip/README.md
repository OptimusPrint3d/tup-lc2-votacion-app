# tup-lc2-votacion-app
Trabajo Práctico de Laboratorio de Computación 2.
Integrantes:
*  Almeida Casiano
*  Beccari Renzo
*  Brion Luciano
*  De Macedo Manuel
*  Villalba Nicolas

Aclaraciones:
Consideramos cambiar algunas medidas respecto al PDF con el objetivo de que tenga un mejor aspecto con la resolución de nuestros monitores.
